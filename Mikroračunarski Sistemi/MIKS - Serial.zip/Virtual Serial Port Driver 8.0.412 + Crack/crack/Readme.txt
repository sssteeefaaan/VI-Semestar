Use firewall to block the internet connection of the application and do not update it. 

Unlimited Site License

Ahmad_k@SCG
000GN1-H6Z94V-GDEXGV-XKPBY5-0ZMHBF-X78NWV